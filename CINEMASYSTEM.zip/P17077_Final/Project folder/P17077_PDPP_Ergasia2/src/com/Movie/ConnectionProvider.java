package com.Movie;
import java.sql.*;

public class ConnectionProvider implements Provider {

	static Connection con=null;
	
	public static Connection getCon()
	{
		try
		{
			Class.forName("org.postgresql.Driver" );
			con=DriverManager.getConnection(connURL, username,pwd);
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return con;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
