package com.Movie;

public class MovieBean {

	String movieid;
	String moviet;
	int movied;
	String moviec;
	int movies;
	String moviedate;
	int moviecin;
	String movietime;
	public String getMovieid() {
		return movieid;
	}
	public void setMovieid(String movieid) {
		this.movieid = movieid;
	}
	public String getMoviet() {
		return moviet;
	}
	public void setMoviet(String moviet) {
		this.moviet = moviet;
	}
	public int getMovied() {
		return movied;
	}
	public void setMovied(int movied) {
		this.movied = movied;
	}
	public String getMoviec() {
		return moviec;
	}
	public void setMoviec(String moviec) {
		this.moviec = moviec;
	}
	public int getMovies() {
		return movies;
	}
	public void setMovies(int movies) {
		this.movies = movies;
	}
	public String getMoviedate() {
		return moviedate;
	}
	public void setMoviedate(String moviedate) {
		this.moviedate = moviedate;
	}
	public int getMoviecin() {
		return moviecin;
	}
	public void setMoviecin(int moviecin) {
		this.moviecin = moviecin;
	}
	public String getMovietime() {
		return movietime;
	}
	public void setMovietime(String movietime) {
		this.movietime = movietime;
	}
	
	String delmovie;
	
	public String getDelmovie() {
		return delmovie;
	}
	
	public void setDelmovie(String delmovie) {
		this.delmovie = delmovie;
	}
	
}
