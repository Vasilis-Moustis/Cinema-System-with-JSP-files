package com.Movie;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mit.ConnectionProvider;
import com.mit.CustomerBean;

public class MovieDAO {

	static Connection con;
	static PreparedStatement pst;
	
	public static int insertMovie(MovieBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("insert into movies "
					+ "values(?,?,?,?,?,?,?,?)");
			pst.setString(1, u.getMovieid());
			pst.setString(2, u.getMoviet());
			pst.setInt(3, u.getMovied());
			pst.setString(4, u.getMoviec());
			pst.setInt(5, u.getMovies());
			pst.setString(6, u.getMoviedate());
			pst.setInt(7,u.getMoviecin());
			pst.setString(8, u.getMovietime());
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
	public static int deleteMovie(MovieBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("DELETE FROM Movies "
					+ "where id = ?");
			pst.setString(1, u.getDelmovie());
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
}
