package com.mit;
import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.servlet.http.HttpSession;

import java.math.BigInteger; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException; 
  
 

public class CustomerDAO {
	
	public static String encryptThisString(String input) 
    { 
        try { 
            MessageDigest md = MessageDigest.getInstance("SHA-512"); 
  
            byte[] messageDigest = md.digest(input.getBytes()); 
  
            BigInteger no = new BigInteger(1, messageDigest); 
  
            String hashtext = no.toString(16); 
  
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
  
            return hashtext; 
        } 
  
        catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        } 
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static Connection con;
	static PreparedStatement pst;
	
	public static int insertCustomer(CustomerBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("insert into customers "
					+ "values(?,?,?,?)");
			pst.setString(1, u.getCustid());
			pst.setString(2, u.getCustname());
			pst.setString(3, encryptThisString(u.getCustpass()));
			pst.setInt(4, u.getCustage());
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
	/*public static int customerLogin(CustomerBean l)
	{
		int status = 0;
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("select * from customers "
					+ "where username = ? and password = ?");
			pst.setString(1, l.getUname());
			pst.setString(2, encryptThisString(l.getPass()));
			
			status=pst.executeUpdate();
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				//HttpSession session = request.getSession();
				//session.setAttribute("username", l.getUname());
				//response.sendRedirect("imCustomer.jsp");
				status = 1;
			} else {
				//HttpSession session = request.getSession();
				//session.setAttribute("username", l.getUname());
				//sendRedirect("login.jsp");
			}
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
		
	}
	*/
	
	public static int insertCAdmin(CustomerBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("insert into ContentAdmins "
					+ "values(?,?,?,?)");
			pst.setString(1, u.getCaid());
			pst.setString(2, u.getCaname());
			pst.setString(3, encryptThisString(u.getCapass()));
			pst.setInt(4, u.getCaage());
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
	public static String getuser(CustomerBean u)
	{
		return u.getUname();
		
	}
	
	public static String getpass(CustomerBean u)
	{
		return encryptThisString(u.getPass());
		
	}
	
	public static int deleteUser(CustomerBean u)
	{
		int status = 0;
		try
		{
			String user = u.getDeluser();
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("DELETE FROM Customers "
					+ "where username = ?");
			pst.setString(1, user);
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
	
}
