package com.mit;

public class CustomerBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	String custid;
	String custname;
	String custpass;
	int custage;
	public String getCustpass() {
		return custpass;
	}
	public void setCustpass(String custpass) {
		this.custpass = custpass;
	}
	public int getCustage() {
		return custage;
	}
	public void setCustage(int custage) {
		this.custage = custage;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	
	
	public String getCaid() {
		return caid;
	}
	public void setCaid(String caid) {
		this.caid = caid;
	}
	public String getCaname() {
		return caname;
	}
	public void setCaname(String caname) {
		this.caname = caname;
	}
	public String getCapass() {
		return capass;
	}
	public void setCapass(String capass) {
		this.capass = capass;
	}
	public int getCaage() {
		return caage;
	}
	public void setCaage(int caage) {
		this.caage = caage;
	}

	String uname;
	String pass;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	String caid;
	String caname;
	String capass;
	int caage;
	
	String deluser;
	public String getDeluser() {
		return deluser;
	}
	public void setDeluser(String deluser) {
		this.deluser = deluser;
	}
	
}
