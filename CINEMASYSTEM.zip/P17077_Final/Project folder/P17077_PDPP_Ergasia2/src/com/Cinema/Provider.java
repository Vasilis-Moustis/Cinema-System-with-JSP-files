package com.Cinema;

public interface Provider {

	String username="postgres";
	String pwd="P17077";
	String connURL="jdbc:postgresql://localhost/P17077_PDPP_Ergasia2";

}
