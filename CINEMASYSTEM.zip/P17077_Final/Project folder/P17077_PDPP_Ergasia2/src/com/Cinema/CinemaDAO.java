package com.Cinema;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.mit.ConnectionProvider;
import com.mit.CustomerBean;

public class CinemaDAO {

	static Connection con;
	static PreparedStatement pst;
	
	public static int assignCinema(CinemaBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("UPDATE Movies SET cinema = ? WHERE ID = ?;");
			pst.setInt(1, u.getCinid());
			pst.setString(2, u.getCinmovie());
			
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
	public static int assignTime(CinemaBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			pst=con.prepareStatement("UPDATE Movies SET Time_Of_Movie = ? WHERE ID = ?;");
			
			pst.setString(1, u.getMovtime());
			pst.setString(2, u.getCinmovie2());
			
			
			status=pst.executeUpdate();
			con.close();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}
	
}
