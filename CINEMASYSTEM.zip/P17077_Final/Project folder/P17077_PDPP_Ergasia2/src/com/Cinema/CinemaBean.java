package com.Cinema;

import java.sql.Date;
import java.sql.Time;

public class CinemaBean {

	String cinmovie;
	int cinid;
	public String getCinmovie() {
		return cinmovie;
	}
	public void setCinmovie(String cinmovie) {
		this.cinmovie = cinmovie;
	}
	public int getCinid() {
		return cinid;
	}
	public void setCinid(int cinid) {
		this.cinid = cinid;
	}
	
	String cinmovie2;
	String movtime;
	public String getCinmovie2() {
		return cinmovie2;
	}
	public void setCinmovie2(String cinmovie2) {
		this.cinmovie2 = cinmovie2;
	}
	public String getMovtime() {
		return movtime;
	}
	public void setMovtime(String movtime) {
		this.movtime = movtime;
	}
	
	
}
