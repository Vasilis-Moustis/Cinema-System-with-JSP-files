package com.Login;

import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mit.ConnectionProvider;

import javax.servlet.http.HttpSession;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	
	public static HttpSession session;
	
	
	public static HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		Login.session = session;
	}

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public static String encryptThisString(String input) 
    { 
        try { 
            // getInstance() method is called with algorithm SHA-512 
            MessageDigest md = MessageDigest.getInstance("SHA-512"); 
  
            // digest() method is called 
            // to calculate message digest of the input string 
            // returned as array of byte 
            byte[] messageDigest = md.digest(input.getBytes()); 
  
            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest); 
  
            // Convert message digest into hex value 
            String hashtext = no.toString(16); 
  
            // Add preceding 0s to make it 32 bit 
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
  
            // return the HashText 
            return hashtext; 
        } 
  
        // For specifying wrong message digest algorithms 
        catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        } 
    } 

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Connection con = null;
			PreparedStatement prepared_stmt, prepared_stmt2, prepared_stmt3 = null;
			ResultSet rs, rs2, rs3 = null;

			con = ConnectionProvider.getCon();

			String uname = request.getParameter("uname");
			String pass = request.getParameter("pass");
			
			prepared_stmt = con.prepareStatement("select * from customers "
					+ "where username = ? and password = ?");
			prepared_stmt.setString(1, uname);
			prepared_stmt.setString(2, encryptThisString(pass));
			
			rs = prepared_stmt.executeQuery();
			
			
			
			prepared_stmt2 = con.prepareStatement("select * from ContentAdmins "
					+ "where username = ? and password = ?");
			prepared_stmt2.setString(1, uname);
			prepared_stmt2.setString(2, encryptThisString(pass));
			
			rs2 = prepared_stmt2.executeQuery();
			
			
			prepared_stmt3 = con.prepareStatement("select * from ServerAdmins "
					+ "where username = ? and password = ?");
			prepared_stmt3.setString(1, uname);
			prepared_stmt3.setString(2, encryptThisString(pass));
			
			rs3 = prepared_stmt3.executeQuery();
			
			
			if (rs.next()) {
				session = request.getSession();
				session.setAttribute("username", uname);
				response.sendRedirect("imCustomer.jsp");
				
			}else if (rs2.next()) {
				session = request.getSession();
				session.setAttribute("username", uname);
				response.sendRedirect("imCAdmin.jsp");
				
			} else if (rs3.next()) {
				session = request.getSession();
				session.setAttribute("username", uname);
				response.sendRedirect("imAdmin.jsp");
				
			} else {
				response.sendRedirect("login.jsp");
			}
			

			
			con.close();

		} catch (Exception E) {
			System.out.println(E);
		}
	}

}
