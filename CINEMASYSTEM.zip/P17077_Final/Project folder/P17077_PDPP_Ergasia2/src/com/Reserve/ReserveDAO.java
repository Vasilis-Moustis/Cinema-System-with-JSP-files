package com.Reserve;
import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mit.ConnectionProvider;

import javax.servlet.http.HttpSession;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Login.Login;
import com.Movie.MovieBean;
import com.mit.ConnectionProvider;

public class ReserveDAO {

	static Connection con;
	static PreparedStatement pst1, pst2, pst3;
	
	
	private static boolean checkSeats(String id, int tickets) throws SQLException {
		pst1=con.prepareStatement("select seats from movies where id = ?");
		pst1.setString(1, id);
		ResultSet rs = pst1.executeQuery();
		int seats = 0;
		while(rs.next())
		{
			seats = rs.getInt("Seats");
		}
		if ((seats - tickets) > 0  && tickets > 0)
			return true;
		else
			return false;
	}

	public static int bookMovie(ReserveBean u)
	{
		int status = 0;
		try
		{
			con = ConnectionProvider.getCon();
			
			if (checkSeats((u.getMovieid()), u.getTickets()))
			{
				HttpSession session = Login.getSession();
				String user =  (String)session.getAttribute("username");
				pst2=con.prepareStatement("insert into Transactions values(?,?,?,?,?,?)");
				pst2.setString(1, u.getName());
				pst2.setString(2, user);
				pst2.setString(3, u.getCcard());
				pst2.setInt(4, u.getPin());
				pst2.setString(5, u.getMovieid());
				pst2.setInt(6, u.getTickets());
				
				status=pst2.executeUpdate();
				pst3 = con.prepareStatement("UPDATE movies SET seats = seats - ? WHERE id = ?");
				
				pst3.setInt(1, u.getTickets());
				pst3.setString(2, u.getMovieid());
				for(int i = 0; i < u.getTickets(); i++)
					pst3.executeQuery();
				
				con.close();
			}
			else
				return status;
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return status;
	}

	

	

}
