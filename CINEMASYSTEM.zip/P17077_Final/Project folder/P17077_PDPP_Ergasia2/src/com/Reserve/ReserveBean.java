package com.Reserve;

public class ReserveBean {

	String movieid;
	int tickets;
	String name;
	String ccard; 
	int pin;
	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCcard() {
		return ccard;
	}

	public void setCcard(String ccard) {
		this.ccard = ccard;
	}

	public String getMovieid() {
		return movieid;
	}
	
	public void setMovieid(String movieid) {
		this.movieid = movieid;
	}
	
	public int getTickets() {
		return tickets;
	}
	
	public void setTickets(int tickets) {
		this.tickets = tickets;
	}	
	
}
