drop table Transactions;
drop table Customers;
drop table Movies;
drop table ServerAdmins;
drop table ContentAdmins;

create table Customers (
	Full_Name VARCHAR(255),
	username VARCHAR(255) unique not null,
	password VARCHAR(255) not null,
	Age numeric(10),
	primary key (Username)
);


create table Movies (
	id VARCHAR(255),
	Title VARCHAR(255),
	Duration numeric(10),
	Category VARCHAR(255),
	Seats numeric(10),
	Date_Of_Play VARCHAR(255),
	Cinema numeric(10),
	Time_Of_Movie varchar(255),
	primary key (ID)
);

create table Transactions(
	Customer_Name varchar(255),
	Customer_User varchar(255),
	CredidCardNo varchar(255),
	CredidCardPin numeric(10),
	movieID varchar(255),
	NoOfTickets  numeric(10),
	FOREIGN KEY (movieID) REFERENCES Movies (id)
);

create table ServerAdmins(
	Full_Name VARCHAR(255),
	username VARCHAR(255) unique not null,
	password VARCHAR(255) not null,
	Age numeric(10),
	primary key (Username)
);

create table ContentAdmins(
	Full_Name VARCHAR(255),
	username VARCHAR(255) unique not null,
	password VARCHAR(255) not null,
	Age numeric(10),
	primary key (Username)
);

insert into Customers (Full_Name, username, password, Age) values ('Mallory Braund', 'mbraund0', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 70);
insert into Customers (Full_Name, username, password, Age) values ('Myra Riquet', 'mriquet1', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 70);
insert into Customers (Full_Name, username, password, Age) values ('Elaine Ladon', 'eladon2', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 26);
insert into Customers (Full_Name, username, password, Age) values ('Mordecai Downie', 'mdownie3', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 49);
insert into Customers (Full_Name, username, password, Age) values ('Maybelle Thebes', 'mthebes4', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 21);
insert into Customers (Full_Name, username, password, Age) values ('Cindi Bengtsson', 'cbengtsson5', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 87);
insert into Customers (Full_Name, username, password, Age) values ('Marcille Dyshart', 'mdyshart6', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 76);
insert into Customers (Full_Name, username, password, Age) values ('Dallas McCarney', 'dmccarney7', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 24);
insert into Customers (Full_Name, username, password, Age) values ('Carmina Callf', 'ccallf8', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 90);
insert into Customers (Full_Name, username, password, Age) values ('Mason Clapston', 'mclapston9', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 55);
insert into Customers (Full_Name, username, password, Age) values ('Myrle Almon', 'malmona', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 34);
insert into Customers (Full_Name, username, password, Age) values ('Danita Sommerling', 'dsommerlingb', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 60);
insert into Customers (Full_Name, username, password, Age) values ('Georgine Folger', 'gfolgerc', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 71);
insert into Customers (Full_Name, username, password, Age) values ('Cecil Farish', 'cfarishd', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 85);
insert into Customers (Full_Name, username, password, Age) values ('Karlene Sahlstrom', 'ksahlstrome', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 29);
insert into Customers (Full_Name, username, password, Age) values ('Ellette Warner', 'ewarnerf', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 19);
insert into Customers (Full_Name, username, password, Age) values ('Ibrahim Gradly', 'igradlyg', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 21);
insert into Customers (Full_Name, username, password, Age) values ('Duane Hanhardt', 'dhanhardth', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 32);
insert into Customers (Full_Name, username, password, Age) values ('Isac Kimmitt', 'ikimmitti', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 85);
insert into Customers (Full_Name, username, password, Age) values ('Iolande Smalley', 'ismalleyj', '5B722B307FCE6C944905D132691D5E4A2214B7FE92B738920EB3FCE3A90420A19511C3010A0E7712B054DAEF5B57BAD59ECBD93B3280F210578F547F4AED4D25', 25);
insert into Customers (Full_Name, username, password, Age) values ('John Cena', 'customer', '154e75fd96b7267f1c852159dccbf194b8c45720e3b6ef3f3d192d731cb8ff03dedc20eec18f28085ab3e3dc3e5b402bd4a67e3174b8cd85fa519c68aac2cade', 20);

insert into ContentAdmins (Full_Name, username, password, Age) values ('John Rambo', 'cadmin', '66cb235458edcbc1d11d8e2aad14ea614bd27a190539302b47e664e1577f37445695ca0e8a3c88e29fd6ea35765f730a9fe22c2c1ea0089fbc8dcb897bd6bad2', 24);

insert into ServerAdmins (Full_Name, username, password, Age) values ('John Wick', 'admin', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', 29);


insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('UVXL588284', 'Oliver Twist', 109, 'Drama', 70, '2019-05-27', 4, '18:38');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('AWOS319582', 'Andy Hardy''s Blonde Trouble', 98, 'Comedy|Romance', 72, '2019-05-28', 6, '20:19');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('ZIFT174869', 'Drumline', 66, 'Comedy|Drama|Musical|Romance', 95, '2019-05-27', 2, '20:14');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('WSQF235643', 'The Dark Valley', 106, 'Western', 68, '2019-05-28', 1, '16:23');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('QSWC636969', 'Little Foxes, The', 70, 'Drama', 61, '2019-05-29', 2, '19:42');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('VEVA233142', 'Kummelin jackpot', 86, 'Comedy', 82, '2019-05-24', 6, '19:04');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('YKUU592094', 'Good Men, Good Women (Hao nan hao nu)', 146, 'Drama|Romance', 78, '2019-05-24', 6, '18:33');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('EKRJ317828', 'To Each His Own Cinema (Chacun son cinéma ou Ce petit coup au coeur quand la lumière s''éteint et que le film commence)', 127, 'Comedy|Drama', 61, '2019-05-28', 1, '17:48');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('CCSQ542776', 'Advantageous', 119, 'Children|Drama|Sci-Fi', 86, '2019-05-24', 5, '17:28');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('LLUP178127', 'Sinbad of the Seven Seas', 115, 'Adventure|Fantasy|Romance', 69, '2019-05-27', 6, '20:43');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('IXGW757397', 'Guilty as Sin', 75, 'Crime|Drama|Thriller', 77, '2019-05-26', 4, '20:54');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('EQJY675674', 'Lotta 2: Lotta flyttar hemifrån', 107, 'Children', 83, '2019-05-27', 2, '21:21');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('ZFRN697933', 'Rally ''Round the Flag, Boys!', 104, 'Comedy', 78, '2019-05-25', 4, '17:31');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('PPYQ489308', 'Color Wheel, The', 140, 'Comedy|Romance', 69, '2019-05-26', 1, '16:35');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('ITZP119485', 'American Carol, An', 87, 'Comedy|Fantasy', 63, '2019-05-29', 5, '20:34');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('ZLEC629862', 'Mafioso', 116, 'Comedy|Crime|Drama', 67, '2019-05-25', 2, '17:29');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('VGDW344329', 'The Living Magoroku', 137, '(no genres listed)', 100, '2019-05-29', 1, '19:25');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('RLCC771937', 'After Life (Wandafuru raifu)', 110, 'Drama|Fantasy', 95, '2019-05-24', 1, '20:14');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('LNYY617028', 'Ballad of a Soldier (Ballada o soldate)', 84, 'Drama|Romance|War', 100, '2019-05-28', 5, '20:53');
insert into Movies (id, Title, Duration, Category, Seats, Date_Of_Play, Cinema, Time_Of_Movie) values ('QLDM006781', 'Breed, The', 106, 'Action|Adventure|Horror', 60, '2019-05-24', 3, '16:44');



